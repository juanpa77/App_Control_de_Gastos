import React, { Component } from 'react';
import Animate from 'rc-animate';
import { render } from 'react-dom';
import Hello from './Hello';
import './style.css';

const Spin = ({ children, show }) => {
  const style = {
    display: show ? 'block' : 'none',
    marginTop: '20px',
    width: '200px',
    height: '200px',
    backgroundColor: 'red',
  };
  return (
    <div>
      <Animate
        component=""
        transitionName="fade"
      >
        {show ? <div key="1" style={style} /> : null}
      </Animate>
    </div>
  ) 
}

class App extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React',
      show: true
    };
  }

  onClick = () => {
    this.setState(prevstate => ({ show: !prevstate.show }))
  }

  render() {
    
    return (
      <div>
        <Hello name={this.state.name} />
        <p>
          Start editing to see some magic happen :)
        </p>
        <Spin show={this.state.show} />
        
        <button onClick={this.onClick}>hello</button>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));
